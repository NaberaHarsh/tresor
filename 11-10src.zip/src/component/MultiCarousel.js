import React, { Component } from "react";
import { Container, Link, Paper } from "@material-ui/core";
import Grid from '@material-ui/core/Grid';

import Skeleton from "@material-ui/lab/Skeleton";

class MultiCarousel extends Component {
  constructor(props) {
    super(props);
    this.state = {
      like_product: [],
      skeleton: new Array(10).fill(true),
      loading: false
    };
  }
 
  static getDerivedStateFromProps(nextProps, prevState) {
    
    if (prevState !== nextProps) {   
      
      return {
          like_product: nextProps.like_product,
    loading: true
      };
    }

    // Return null to indicate no change to state.
    return null;
  }
  render() {
    const { like_product, loading, skeleton } = this.state;
    
      
    return (
      
      <div>
      <Container maxWidth="lg" className="card1">
        <Paper style={{ width: "100% ! important" }}>
          <h5 style={{ padding: "20px",marginLeft:'20px' }} className="features">
          Most Liked Products
          </h5>
          <div>
            <Container maxWidth="lg">
              <div className="row">
                <div
                 
                  data-items="1,2,4,5"
                  data-slide="1"
                  id="MultiCarousel"
                  data-interval="900"
                >
                  <div >
                  <Grid container spacing={3}>
                    {loading === true && like_product.length !== 0 ? (
                      <>
                        {like_product.map((data, index) => (
                            <Grid item md={3} lg={3} sm={12} xs={12}>
                          <div className="item" key={`product-${index}`} style={{border:"1px solid #aeaeae"}}>
                            {/* <Paper > */}
                              <div className="pad15">
                                <div className="imgwidth">
                                
                                    <img
                                     key={`product-img-${index}`}
                                      className="img2"
                                      src={`http://tresorjewelryinc.com/tresor-admin/${data.url}`}
                                      alt=""
                                    />{" "}
                                
                                </div>
                                <div className="Rating">
                                  <p
                                    style={{
                                      textAlign: "center",
                                      color: "black !important",
                                      fontSize: "18px !important",
                                      marginTop:'40px'
                                    }}
                                    key={`product-img-text-${index}`}
                                  ><Link href={`/Details/${data.product_id}`}>
                                 {data.name} {" "}
                                </Link>
                                    
                                    <br />{" "}
                                  </p>
                                </div>
                              </div>
                            {/* </Paper> */}
                          </div>
                          </Grid>
                        ))}
                      </>
                    ) : (
                      <>
                        {" "}
                        {skeleton.map((index) => (
                           <Grid item md={3} lg={3} sm={12} xs={12}>
                          <div className="item" key={`skel-product-${index}`}>
                            <Paper>
                              <div className="pad15">
                                <div className="imgwidth">
                                  <Skeleton
                                    variant="rect"
                                    className="skeleton-img"
                                  />
                                </div>
                                <div className="Rating">
                                  <div>
                                    <Skeleton height={6} />
                                    <Skeleton height={6} width="80%" />
                                  </div>
                                </div>
                              </div>
                            </Paper>
                          </div>
                          </Grid>
                        ))}
                      </>
                    )}
                    </Grid>
                  </div>
                 
                </div>
              </div>
            </Container>
          </div>
        </Paper>
      </Container>
    </div>
    );
  }
}

export default MultiCarousel;
