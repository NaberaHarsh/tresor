const apiEndPoint = "http://tresorjewelryinc.com";
// const apiEndPoint = "http://45.77.147.212";

const config = {
  url: {
   Dashboard:`${apiEndPoint}/Api`,
   GetHead:`${apiEndPoint}/api/gethead`,
   Products:`${apiEndPoint}/api/products`,
   Detailproduct:`${apiEndPoint}/api/product`,
   Login:`${apiEndPoint}/auth/login`,
   Register:`${apiEndPoint}/auth/registration`,
   ForgotPassword:`${apiEndPoint}/user/forgotpass/gen`,
   ResetPassword:`${apiEndPoint}/user/updatepass`,
   Search:`${apiEndPoint}/api/search?search={search_keyword}`,
  }
};
export default config;

